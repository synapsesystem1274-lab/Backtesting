# Synapse Bar Replay MVP

## Run it
Open `index.html` in a modern browser, or publish the folder to GitHub Pages.

## Load historical data
Use a CSV with a header row containing:
`time,open,high,low,close`
Optional extra columns (such as volume) are ignored.

`time` may be:
- Unix timestamp in seconds
- Unix timestamp in milliseconds
- Date string parseable by the browser, preferably ISO 8601, e.g. `2025-01-02T08:00:00Z`

Prices should be numeric. Rows are sorted by time and duplicate timestamps are removed.

## Included
- Candle-by-candle replay, play/pause, speed and jump controls
- Manual simulated long/short ticket
- 1:3 take-profit calculator
- Local trade journal and simple win-rate / R / profit-factor stats
- Conservative same-candle handling: if both SL and TP are inside one candle, SL is counted first

## Important limitations
- The demo candles are synthetic and are only for testing the interface. They are not market data.
- This MVP does not fetch forex data automatically. You must supply lawful historical OHLC CSV data.
- The current version supports one open simulated trade at a time.
- Trades are stored in the browser's local storage on that device/browser. Export/backup is not implemented yet.
- Chart library is loaded from a public CDN, so an internet connection is required to display the chart.
- This is a practice tool, not financial advice or a broker connection.
